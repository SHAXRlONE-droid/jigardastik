# @jigardastikbot

Telegram sticker bot starter.

## Ishga tushirish

1. Python 3.12 o'rnating.
2. `pip install -r requirements.txt`
3. `BOT_TOKEN` environment variable yarating.
4. `python bot.py`

Tokenni hech qachon ommaga yubormang.

Bu versiya:
- /start
- /help
- rasm -> sticker
- sticker ma'lumotini ko'rsatish

Keyingi kengaytirishlar:
- sticker pack yaratish
- packga qo'shish/o'chirish
- video/GIF -> video sticker
- emoji sticker
- admin panel
