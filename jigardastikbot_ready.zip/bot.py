import asyncio
import logging
import os
import tempfile
from pathlib import Path

from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.types import Message, FSInputFile
from aiogram.enums import ContentType
from PIL import Image

TOKEN = os.getenv("BOT_TOKEN")
if not TOKEN:
    raise RuntimeError("BOT_TOKEN environment variable is not set")

bot = Bot(TOKEN)
dp = Dispatcher()

WELCOME = (
    "👋 Salom! Men sticker botman.\n\n"
    "🖼 Rasm yuboring — stickerga aylantiraman.\n"
    "🎥 Video/GIF yuboring — video sticker tayyorlashga harakat qilaman.\n\n"
    "Buyruqlar:\n"
    "/start — boshlash\n"
    "/help — yordam"
)

@dp.message(CommandStart())
async def start(message: Message):
    await message.answer(WELCOME)

@dp.message(Command("help"))
async def help_cmd(message: Message):
    await message.answer(
        "🖼 Oddiy rasm yuboring. Men uni 512x512 sticker formatiga moslab beraman.\n"
        "Keyin sticker pack funksiyalarini qo‘shish mumkin."
    )

@dp.message(F.content_type == ContentType.PHOTO)
async def photo_to_sticker(message: Message):
    tmp = Path(tempfile.mkdtemp(prefix="sticker_"))
    src = tmp / "input.jpg"
    out = tmp / "sticker.webp"

    try:
        await bot.download(message.photo[-1], destination=src)

        img = Image.open(src).convert("RGBA")
        img.thumbnail((512, 512), Image.Resampling.LANCZOS)

        canvas = Image.new("RGBA", (512, 512), (0, 0, 0, 0))
        x = (512 - img.width) // 2
        y = (512 - img.height) // 2
        canvas.alpha_composite(img, (x, y))
        canvas.save(out, "WEBP", lossless=True, quality=100, method=6)

        await message.answer_sticker(FSInputFile(out))
    except Exception as e:
        logging.exception(e)
        await message.answer("❌ Rasmni stickerga aylantirishda xatolik yuz berdi.")
    finally:
        for p in tmp.glob("*"):
            p.unlink(missing_ok=True)
        tmp.rmdir()

@dp.message(F.content_type == ContentType.STICKER)
async def sticker_info(message: Message):
    s = message.sticker
    await message.answer(
        f"🧩 Sticker ID:\n`{s.file_id}`\n\n"
        f"Emoji: {s.emoji or '—'}",
        parse_mode="Markdown"
    )

@dp.message()
async def fallback(message: Message):
    await message.answer("🖼 Rasm yuboring — uni stickerga aylantiraman.")

async def main():
    logging.basicConfig(level=logging.INFO)
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
